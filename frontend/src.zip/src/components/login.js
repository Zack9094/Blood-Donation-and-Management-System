import react from 'react'
import {Link} from 'react-router-dom'

import './SignUp.css'
const login=()=>{
    return(
        <div>
 <center>
            <div class="wrapper" >
               
      <div class="login">
        <h1><span>Login</span></h1>
      </div>
      <div class="input-box">
        <label for="user_id"><p>Email</p></label>
        <input type="text" id="user_id" class="input_field" required="" placeholder="Enter your email" value=""/>
        
        </div>
      <div class="input-box">
        <label for="user_password"><p>Password</p></label><input type="password" id="user_password" class="input_field" required="" placeholder="Enter your password" value=""/>
      </div>
      <label><input type="checkbox"/>Remember me</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a class="a1" href="" >  forgot password?</a><br></br>
     <Link to='/user'>
      <button class="btn" type="submit">login</button>
    </Link>
    
    </div>
 </center>
        </div>
    )
    
}
export default login;
