import react from 'react'

import {Link} from 'react-router-dom'
import { useNavigate } from "react-router-dom";
function user() {



  return (
   
             <div>
               <center>
          <Link to="/donorregistration">
          <button className='user'  ><h3>Donate</h3></button>
         </Link>
          <Link to="/donorlist">
          <button className='admin' ><h3>Receive</h3></button>
          </Link>
         
          </center>
             </div>

            
  );
}

export default user;