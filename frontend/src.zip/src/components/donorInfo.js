import React, { useEffect, useState } from 'react';
import {useNavigate } from 'react-router-dom'
import './DR.css'
import DP from './reqInfo'
const DonorInfo = () => {

  const [cand, setCand] = useState([]);
  const [showDiv1, setShowDiv1] = useState(true);
  const [showDiv2, setShowDiv2] = useState(false);
  const [showDiv3, setShowDiv3] = useState(false);
  const [showDiv, setShowDiv] = useState(true);
  const [selectedId, setSelectedId] = useState(null);
  const navigate = useNavigate();
  
  useEffect((c) => {
    getCand();

  }, []);

  const div1 = () => {
    setShowDiv2(false);
    setShowDiv1(true);
  }
  
  const div2 = () => {
    setShowDiv1(false);
    setShowDiv2(true);
  }
  const profile=()=>{
    // setShowDiv(false);
    //   setShowDiv3(true);
      
  }

  const getCand = async () => {
    try {
      const res = await fetch("http://localhost:50333/donorlist", {
        headers: {
          authorization: JSON.parse(localStorage.getItem('token'))
        }
      });

      if (!res.ok) {
        throw new Error("Server Error");
      }

      const result = await res.json();
      setCand(result);

    } catch (err) {
      console.error(err);
    }
  };

  return (
<>
   {showDiv3 && ( 
     <div >
     <DP/>
    </div>)}

     {showDiv &&(
    <div className='mdiv' >
   
      <table className='donInfo'>
       
        <tr >
          <div className='hed'>
          <div id='reqdon' onClick={div1}>Requests({cand.length})</div><div id='reqdon' onClick={div2}>Donations</div>
          </div>
        </tr>
      
<div className='inndiv'>
        <tr>
          
            {cand.length > 0 ? (
              cand.map((item, idx) => (

                (showDiv1  && <div className='requests'>
                  <div className='img'><div class="blood-icon-20"> <span>{item.bloodGrp}</span></div>
                    <p className='unit'>3 Unit</p>
                  </div>
                  <div className='info'>
                    <p id='h'>{item.name}</p>
                    <p>Date.now</p>
                    <p>📍{item.addrs}</p>
                  </div>
                 <td className='view'><div onClick={profile(item._id)} >View</div></td>
                </div>)

              ))
            ) : (
              <tr>
                <td colSpan="10" style={{ textAlign: "center" }}>
                  No Result Found
                </td>
              </tr>
            )}
            <div>
            </div>
         

    



            {cand.length > 0 ? (
              cand.map((item, idx) => (

                (showDiv2  && <div className='requests'>
                  <div className='img'><div class="blood-icon-20"> <span>{item.bloodGrp}</span></div>
                    <p className='unit'>3 Unit</p>
                  </div>
                  <div className='info'>
                    <p id='h'>{item.name}</p>
                    <p>Date.now</p>
                    <p>📍{item.addrs}</p>
                  </div>
                 <td className='view'><div onClick={profile}>View</div></td>
                </div>)

              ))
            ) : (
              <tr>
                <td colSpan="10" style={{ textAlign: "center" }}>
                  No Result Found
                </td>
              </tr>
            )}
            <div>
            </div>
         




        </tr>
        </div>
      </table>
    </div>)}

  </>
  );
};

export default DonorInfo;
