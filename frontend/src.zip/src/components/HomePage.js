import React,{useEffect,useState} from 'react'
import {Link, useNavigate } from 'react-router-dom'

import "./SignUp.css";
import DL from "./DonorList";
import SL from './StokeBloodList';
import IN from "./Inventory";
import BR from'./BloodRecord';
import RI from './donorInfo';
const Homepage=()=>{
const [donorlist,setDonorlist]=useState({})
const [showDiv,setShowDiv]=useState(null)
const [showDiv2,setShowDiv2]=useState(true)
const [showInventoryForm, setShowInventoryForm] = useState(false);

//  const ShowDiv=()=>{
//     setShowDiv[](True)
//  }
     useEffect(()=>{
        getDonorlist()
     },[])
 const getDonorlist=async ()=>{
       
        const res=await fetch("http://localhost:50333/donorlist",{
            headers:{
                authorization:JSON.parse(localStorage.getItem('token'))
            },
           // body: JSON.stringify({name,addrs,age,gen,email,fname,mname,bloodGrp,city,mobno})
        });
      if (!res.ok) {
    throw new Error("Server error");
}

        const result = await res.json();
        setDonorlist(result)
      console.warn(donorlist)
    }

return(
<div className='homepage'>

    <div className='left'>
        <Link onClick={()=>setShowDiv(1)}><div className='left-div'> Inventory</div></Link>
        <Link onClick={()=>setShowDiv(2)}><div className='left-div'>donor</div></Link> 
        <Link onClick={()=>setShowDiv(3)}><div className='left-div'>Organisations</div></Link> 
   </div>

   <div className='right'>
    {/* { showDiv===1 &&
    <div>
    <a href="/donorregistration">
    <div className='inv'>+inventory</div>
    </a>
    <div>{<SL/>}</div>  
</div>} */}

 {showDiv===1 &&(
    <div >
   <Link onClick={() => {setShowInventoryForm(true)
                        setShowDiv2(false)}}><div className='inv' >+inventory</div></Link> 
    {showInventoryForm && (<IN setShowForm={setShowInventoryForm} 
                               setShowdiv2={setShowDiv2}/>
     )}
         { showDiv2 &&(
            <div className='indiv'> <BR /></div>)}
           

          </div>
        )}

{ showDiv===2 &&
    <div >
    <a href="/donorregistration">
    <div className='inv'>+Donor Information</div>
    </a>
    <div className='indiv'>{<RI/>}</div>  
</div>}

{ showDiv===3 &&
    <div >
    <a href="/donorregistration">
    <div className='inv'>+Donor Information</div>
    </a>
    <div className='indiv'>{<DL/>}</div>  
</div>}
   </div>
   
</div>
);
}
export default Homepage;



 {/* <div >
            <a href='http://localhost:3000/signup'>SignUp</a>
        </div>
        
    <div>
        <a href='http://localhost:3000/donorregistration'>Donor Registration</a>
    </div>
    
    <div>
        <a href='http://localhost:3000/donorlist'>Donors divst</a>
    </div>
        
    <div>
         <a href='http://localhost:3000/exchangeblooddivst'>Exchange Blood</a>
    </div>
       
    <div>
         <a href='http://localhost:3000/outstokeblooddivst'>Out-Stoke Blood divst</a>
    </div>
    
    <div>
        <a href='http://localhost:3000/stokeblooddivst'>Stoke Blood divst</a>
    
    </div>
        
    <div>
        <a href='http://localhost:3000/ngoinfo'>NGO Info</a>
    </div> */}
  